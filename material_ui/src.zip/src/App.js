// import logo from '../src/images/logo.svg';
import './App.css';
import Dashboard from './Component/Dashboard';
import Footer from './Component/Footer'
function App() {
  return (
    <div className="App">
       
      <Dashboard/>
      <Footer/>
    </div>
  );
}

export default App;
